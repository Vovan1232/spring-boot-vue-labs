package ua.chytalnia.articleai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArticleAiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ArticleAiApplication.class, args);
    }
}
